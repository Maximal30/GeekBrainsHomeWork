package com.inv1ct0.lesson_1;

class Orange extends Fruit {
    Orange() {
        super(1.5f);
    }
}
