package com.inv1ct0.lesson_1;

class Apple extends Fruit {
    Apple() {
        super(1.0f);
    }
}