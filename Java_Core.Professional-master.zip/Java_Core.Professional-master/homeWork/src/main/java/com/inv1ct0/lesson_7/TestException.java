package com.inv1ct0.lesson_7;

class TestException extends Exception {
    TestException(){}
}